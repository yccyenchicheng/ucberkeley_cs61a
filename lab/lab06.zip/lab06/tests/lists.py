test = {
  'name': 'List Mutation',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> lst = [1, 2, 3, 4, 5, 6]
          >>> lst[4] = 1
          >>> lst
          00e7cd68d09bab441fbab53087dab4b7
          # locked
          >>> lst[2:4] = [9, 8]
          >>> lst
          4559cbec2cddffe7ab8ae75d1acce970
          # locked
          >>> lst[3] = ['hi', 'bye']
          >>> lst
          3dbe7bcfc53d50645da78b54740e3f92
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> lst[3:] = ['oski', 'bear']
          >>> lst
          8d79b5482ca45a4435681b3f2824e1da
          # locked
          >>> lst[1:3] = [2, 3, 4, 5, 6, 7, 8]
          >>> lst
          5584d413916a7762ef0848b100c335d7
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> lst == lst[:]
          ede6df328b7c3fa6304f7eb1608d9dc4
          # locked
          >>> lst is lst[:]
          a559f517e8f86de30b928d7e29ec2331
          # locked
          >>> a = lst[:]
          >>> a[0] = 'oogly'
          >>> lst
          5584d413916a7762ef0848b100c335d7
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
